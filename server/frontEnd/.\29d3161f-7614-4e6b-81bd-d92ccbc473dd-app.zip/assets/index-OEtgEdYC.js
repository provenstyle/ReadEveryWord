import{l as e,o,v as n}from"./index-2tD40EwM.js";const s=e({__name:"index",setup(t){return(a,r)=>(o(),n("h1",null,"Foo"))}});export{s as default};
